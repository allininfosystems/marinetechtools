<?php

namespace Ess\M2ePro\Block\Adminhtml\Ebay\Template\Description\Preview;

use Ess\M2ePro\Block\Adminhtml\Magento\AbstractBlock;

class Body extends AbstractBlock
{
    protected $_template = 'ebay/template/description/body.phtml';
}